__**This datapack allow you to easily detect when the player if afk**__

you either run your own function from the function tag "#afk:become_afk" and "#afk:leave_afk" + every afk player have the tag "afk"

or you can change the settings function so that it automaticly kick afk players (you need to increse the permission of datapacks up to 3 in the server's file for it to work)

player with the tag afk.except won't concidered as afk